package vinay1;

//import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.AnnotationConfiguration;
public class Student
{
	public static void main(String[] Args)
	{
		//Scanner sc=new Scanner(System.in);
		SessionFactory sf=new  AnnotationConfiguration().configure("hiber.cfg.xml").buildSessionFactory();
		Session session =sf.openSession();
		session.beginTransaction();
		
		StudentDetails obj=new StudentDetails();
		StudentAddress stuAddObj= new StudentAddress();
		stuAddObj.setAddress("Delhi");
		
		//obj.setId(101);
		obj.setName("Naman");
		obj.setStudentAddress(stuAddObj);
		
		
		session.save(obj);
		session.save(stuAddObj);
		session.getTransaction().commit();
		session.close();
	    
	}

}
