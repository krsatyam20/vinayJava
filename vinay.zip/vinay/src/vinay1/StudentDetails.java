package vinay1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class StudentDetails
{	
    @Id	
    @GeneratedValue
	int id;
	
    String name;
    
    @OneToOne
	StudentAddress StudentAddress;
    //String address;
	
    public StudentAddress getStudentAddress() {
		return StudentAddress;
	}
	public void setStudentAddress(StudentAddress studentAddress) {
		StudentAddress = studentAddress;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	/*
	 * public String getAddress() { return address; } public void setAddress(String
	 * address) { this.address = address; }
	 */

}
